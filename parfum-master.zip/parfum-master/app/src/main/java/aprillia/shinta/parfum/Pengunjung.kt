package aprillia.shinta.parfum

data class Pengunjung(
    var id: String? = null,
    var nama: String? = null,
    var noHp: String? = null,
    var alamat: String? = null,
    var merek: String? = null,
    var ukuran: String? = null,
    var jumlah: String? = null
)
